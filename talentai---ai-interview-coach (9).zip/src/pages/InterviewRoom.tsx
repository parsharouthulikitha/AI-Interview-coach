import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Mic, 
  MicOff, 
  Video, 
  VideoOff, 
  Send, 
  ArrowRight, 
  CheckCircle,
  AlertCircle,
  Loader2,
  Trophy,
  BrainCircuit,
  MessageSquare,
  Sparkles,
  Zap,
  Award
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

const InterviewRoom = () => {
  const { user } = useAuth();
  const [step, setStep] = useState<'setup' | 'interview' | 'feedback'>('setup');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [config, setConfig] = useState({
    role: "Senior Software Engineer",
    industry: "Tech",
    experience: "Senior",
    count: 3
  });
  
  const [questions, setQuestions] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [transcript, setTranscript] = useState<{ role: string; content: string }[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [feedback, setFeedback] = useState<any>(null);
  const [cameraOn, setCameraOn] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Speech Recognition setup (kept as frontend-only feature)
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event: any) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            setCurrentAnswer(prev => prev + event.results[i][0].transcript + ' ');
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
        setError("Speech recognition failed. Please try again.");
      };
    } else {
      setError("Speech recognition is not supported in this browser.");
    }
  }, []);

  const toggleCamera = async () => {
    if (cameraOn) {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      setCameraOn(false);
      setError(null);
    } else {
      try {
        setError(null);
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { width: 1280, height: 720 }, 
          audio: true 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraOn(true);
      } catch (err: any) {
        console.error("Camera access error:", err);
        setError(`Camera access failed: ${err.message || 'Unknown error'}`);
      }
    }
  };

  const startInterview = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ai/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      });
      if (!res.ok) throw new Error("Failed to get questions");
      const data = await res.json();
      setQuestions(data.questions);
      setTranscript([{ role: "interviewer", content: data.questions[0] }]);
      setStep('interview');
    } catch (error: any) {
      console.error(error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      setError(null);
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        console.error("Start listening error:", err);
        setError("Could not start speech recognition.");
      }
    }
  };

  const handleNext = async () => {
    const updatedTranscript = [
      ...transcript,
      { role: "candidate", content: currentAnswer }
    ];

    if (currentIndex < questions.length - 1) {
      const nextIndex = currentIndex + 1;
      setTranscript([
        ...updatedTranscript,
        { role: "interviewer", content: questions[nextIndex] }
      ]);
      setCurrentIndex(nextIndex);
      setCurrentAnswer("");
    } else {
      finishInterview(updatedTranscript);
    }
  };

  const finishInterview = async (finalTranscript: any[]) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/ai/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: config.role, transcript: finalTranscript }),
      });
      if (!res.ok) throw new Error("Failed to generate feedback");
      const data = await res.json();
      setFeedback(data);
      setStep('feedback');
    } catch (error: any) {
      console.error(error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto h-[calc(100vh-200px)]">
      <AnimatePresence mode="wait">
        {step === 'setup' && (
          <motion.div 
            key="setup"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="flex flex-col items-center justify-center h-full gap-8"
          >
            <div className="text-center">
              <h1 className="text-4xl font-bold mb-4">Start Your <span className="gradient-text">Interview</span></h1>
              <p className="text-slate-400">Configure your simulation settings for the best experience.</p>
            </div>
            
            <div className="glass-card w-full max-w-lg space-y-6">
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-sm flex items-start gap-3">
                  <AlertCircle className="shrink-0" size={18} />
                  <p>{error}</p>
                </div>
              )}
              <div className="space-y-4 text-left">
                <div>
                  <label className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-2 block">Target Role</label>
                  <input 
                    type="text" 
                    value={config.role}
                    onChange={e => setConfig({...config, role: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
                <div>
                  <label className="text-sm font-bold text-slate-500 uppercase tracking-widest mb-2 block">Industry</label>
                  <input 
                    type="text" 
                    value={config.industry}
                    onChange={e => setConfig({...config, industry: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={toggleCamera}
                  className={`flex-1 py-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
                    cameraOn ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-white/5 border border-white/10"
                  }`}
                >
                  {cameraOn ? <Video size={18} /> : <VideoOff size={18} />}
                  {cameraOn ? "Camera Ready" : "Enable Camera"}
                </button>
              </div>

              <button 
                onClick={startInterview}
                disabled={loading}
                className="w-full btn-primary h-14 text-lg flex items-center justify-center gap-3"
              >
                {loading ? <Loader2 className="animate-spin" /> : <><Zap size={20} /> Initialize AI Interviewer</>}
              </button>
            </div>
          </motion.div>
        )}

        {step === 'interview' && (
          <motion.div 
            key="interview"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid lg:grid-cols-2 gap-10 h-full"
          >
            {/* Visual Panel */}
            <div className="space-y-6 h-full flex flex-col">
              <div className="glass-card flex-1 min-h-[400px] relative overflow-hidden bg-slate-900 rounded-3xl border-white/10">
                <video 
                  ref={videoRef} 
                  autoPlay 
                  muted 
                  playsInline 
                  className={`w-full h-full object-cover rounded-3xl ${cameraOn ? 'opacity-100' : 'opacity-0'}`} 
                />
                {!cameraOn && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                    <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center text-slate-600">
                      <VideoOff size={40} />
                    </div>
                    <p className="text-slate-500">Camera is disabled</p>
                  </div>
                )}
                {/* AI Overlay indicator */}
                <div className="absolute top-6 left-6 flex items-center gap-2 px-3 py-1.5 glass rounded-full text-xs font-bold text-indigo-400 animate-pulse">
                  <Sparkles size={14} /> AI Processing
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={toggleListening}
                  className={`flex-1 py-4 rounded-2xl flex items-center justify-center gap-3 transition-all text-lg font-bold ${
                    isListening ? "bg-red-500 text-white shadow-xl shadow-red-500/30 pulse-red" : "bg-indigo-600 text-white"
                  }`}
                >
                  {isListening ? <><MicOff size={24} /> Stop Recording</> : <><Mic size={24} /> Record Answer</>}
                </button>
                <button 
                  onClick={handleNext}
                  disabled={!currentAnswer.trim()}
                  className="px-8 py-4 bg-white/5 border border-white/10 text-white rounded-2xl hover:bg-white/10 disabled:opacity-50 transition-all font-bold flex items-center gap-2"
                >
                  Submit <ArrowRight size={20} />
                </button>
              </div>
            </div>

            {/* Content Panel */}
            <div className="flex flex-col gap-6 h-full">
              <div className="glass-card flex-1 overflow-y-auto space-y-8 custom-scrollbar p-10">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg">
                    <BrainCircuit className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Question {currentIndex + 1}/{questions.length}</h3>
                    <p className="text-xs text-slate-500 uppercase tracking-widest">Active Simulation</p>
                  </div>
                </div>

                <div className="p-8 bg-white/5 rounded-3xl border border-white/10">
                  <p className="text-2xl font-medium leading-relaxed italic text-indigo-200">
                    "{questions[currentIndex]}"
                  </p>
                </div>

                <div className="space-y-4">
                  <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Your Transcript</p>
                  <div className="flex-1 bg-black/30 rounded-2xl p-6 border border-white/5 min-h-[150px] max-h-[250px] overflow-y-auto">
                    {currentAnswer ? (
                      <p className="text-slate-300 leading-relaxed italic">{currentAnswer}</p>
                    ) : (
                      <p className="text-slate-600 italic">Start speaking or record your answer...</p>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="text-xs text-slate-500 text-center uppercase tracking-[0.2em] font-medium opacity-50">
                Secure Session • AI Powered Analysis Active
              </div>
            </div>
          </motion.div>
        )}

        {step === 'feedback' && feedback && (
          <motion.div 
            key="feedback"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto space-y-10 py-10"
          >
            <div className="text-center mb-12">
              <div className="w-20 h-20 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-emerald-500/30">
                <Trophy size={40} />
              </div>
              <h1 className="text-4xl font-bold mb-4">Interview <span className="gradient-text">Complete</span></h1>
              <p className="text-slate-400">Great work! Here's how you performed according to our AI analysis.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { label: "Overall Score", value: feedback.score, icon: Award, color: "text-indigo-400", bg: "bg-indigo-500/10" },
                { label: "Communication", value: feedback.communicationScore, icon: MessageSquare, color: "text-blue-400", bg: "bg-blue-500/10" },
                { label: "Confidence", value: feedback.confidenceScore, icon: Sparkles, color: "text-amber-400", bg: "bg-amber-500/10" },
                { label: "Expectations", value: feedback.preparednessScore, icon: CheckCircle, color: "text-emerald-400", bg: "bg-emerald-500/10" },
              ].map((m, i) => (
                <div key={i} className="glass-card text-center flex flex-col items-center">
                  <div className={`w-12 h-12 ${m.bg} ${m.color} rounded-xl flex items-center justify-center mb-4`}>
                    <m.icon size={24} />
                  </div>
                  <p className="text-3xl font-bold mb-1">{m.value}%</p>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">{m.label}</p>
                </div>
              ))}
            </div>

            <div className="glass-card p-10 space-y-8">
              <div className="space-y-4">
                <h3 className="text-2xl font-bold flex items-center gap-3">
                  <BrainCircuit className="text-indigo-400" /> AI Feedback
                </h3>
                <p className="text-slate-400 leading-relaxed text-lg">
                  {feedback.feedback}
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-white/5 rounded-2xl p-6 border border-white/5">
                  <h4 className="font-bold mb-4 text-indigo-400 uppercase tracking-widest text-xs">Improvement Areas</h4>
                  <ul className="space-y-3">
                    {feedback.improvementTips.map((tip: string, i: number) => (
                      <li key={i} className="text-sm text-slate-300 flex gap-3">
                        <AlertCircle className="text-amber-500 shrink-0" size={16} />
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-white/5 rounded-2xl p-6 border border-white/5 flex flex-col justify-center items-center text-center">
                  <h4 className="font-bold mb-4 text-emerald-400 uppercase tracking-widest text-xs">Next Steps</h4>
                  <p className="text-sm text-slate-400 mb-6">Want to improve your score? Try another session focusing on these highlighted areas.</p>
                  <button onClick={() => window.location.reload()} className="btn-primary w-full">Try Again</button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .pulse-red {
          animation: pulse-red 2s infinite;
        }
        @keyframes pulse-red {
          0% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); }
          70% { box-shadow: 0 0 0 15px rgba(239, 68, 68, 0); }
          100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.02);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};

export default InterviewRoom;
