import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Editor from "@monaco-editor/react";
import { 
  Play, 
  Send, 
  ChevronLeft, 
  Timer, 
  Settings,
  Brain,
  MessageSquare,
  ChevronRight,
  TrendingUp,
  Award,
  Zap,
  CheckCircle2,
  XCircle,
  Loader2,
  Building2,
  Tag,
  Download
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";
import { INITIAL_CHALLENGES } from "../constants/challenges";

interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: "easy" | "medium" | "hard";
  category: string;
  starterCode?: Record<string, string>;
  testCases?: any[];
  constraints?: string[];
  companyTags?: string[];
}

const CodeAssessment = () => {
  const { challengeId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("javascript");
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isRunning, setIsRunning] = useState(false);
  const [output, setOutput] = useState<any>(null);
  const [feedback, setFeedback] = useState<any>(null);
  const [seconds, setSeconds] = useState(0);
  const [activeTab, setActiveTab] = useState<'description' | 'feedback' | 'chat'>('description');

  // Timer logic
  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds(s => s + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    const fetchChallenge = async () => {
      if (!challengeId) return;
      setLoading(true);
      try {
        // Fallback to local data
        const localChallenge = INITIAL_CHALLENGES.find(c => c.id === challengeId);
        if (localChallenge) {
          setChallenge(localChallenge as Challenge);
          setCode(localChallenge.starterCode?.[language] || getDefaultCode(language));
        } else {
          // Second fallback to previous hardcoded logic for robustness
          const defaults: Record<string, any> = {
            twosum: {
              id: "twosum",
              title: "Two Sum",
              difficulty: "easy",
              category: "Arrays",
              description: "Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`.\n\nYou may assume that each input would have exactly one solution, and you may not use the same element twice.\n\nYou can return the answer in any order.",
              constraints: ["2 <= nums.length <= 10^4", "-10^9 <= nums[i] <= 10^9", "-10^9 <= target <= 10^9"],
              starterCode: {
                javascript: "/**\n * @param {number[]} nums\n * @param {number} target\n * @return {number[]}\n */\nvar twoSum = function(nums, target) {\n    \n};",
                python: "class Solution:\n    def twoSum(self, nums: List[int], target: int) -> List[int]:\n        pass"
              }
            }
          };
          if (defaults[challengeId]) {
            setChallenge(defaults[challengeId]);
            setCode(defaults[challengeId].starterCode?.[language] || getDefaultCode(language));
          }
        }
      } catch (error) {
        console.error("Error fetching challenge:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchChallenge();
  }, [challengeId]);

  const getDefaultCode = (lang: string) => {
    if (lang === "javascript") return "// Write your code here\n";
    if (lang === "python") return "# Write your code here\n";
    if (lang === "cpp") return "#include <iostream>\nusing namespace std;\n\nint main() {\n    return 0;\n}\n";
    if (lang === "java") return "public class Main {\n    public static void main(String[] args) {\n        \n    }\n}\n";
    return "";
  };

  const runCode = async () => {
    setIsRunning(true);
    setOutput(null);
    try {
      const res = await fetch("/api/ai/code-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ challenge, code, language }),
      });
      const data = await res.json();
      setOutput(data);
    } catch (error) {
      console.error(error);
    } finally {
      setIsRunning(false);
    }
  };

  const submitCode = async () => {
    if (!user || !challenge) return;
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/ai/code-review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ challenge, code, language }),
      });
      const data = await res.json();
      setFeedback(data);
      setActiveTab('feedback');

      // Local save logic could go here
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const downloadReport = () => {
    if (!feedback || !challenge) return;
    
    const report = {
      name: user?.name,
      email: user?.email,
      challenge: challenge.title,
      difficulty: challenge.difficulty,
      language: language,
      score: feedback.score,
      summary: feedback.summary,
      timeComplexity: feedback.timeComplexity,
      spaceComplexity: feedback.spaceComplexity,
      optimizations: feedback.optimizations,
      attemptTime: formatTime(seconds),
      code: code,
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Interview_Report_${challenge.id}_${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-screen text-slate-400">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mb-4" />
        <p>Initializing assessment environment...</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 top-16 bg-[#0a0a10] flex flex-col">
      {/* Header Bar */}
      <div className="h-14 border-b border-white/5 bg-white/5 backdrop-blur-md flex items-center justify-between px-4 z-10">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/coding-dashboard')}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors text-slate-400"
          >
            <ChevronLeft size={20} />
          </button>
          <div className="h-4 w-px bg-white/10" />
          <h1 className="font-bold text-slate-200">{challenge?.title}</h1>
          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
            challenge?.difficulty === 'easy' ? 'bg-emerald-500/10 text-emerald-500' :
            challenge?.difficulty === 'medium' ? 'bg-amber-500/10 text-amber-500' :
            'bg-rose-500/10 text-rose-500'
          }`}>
            {challenge?.difficulty}
          </span>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-slate-400 font-mono text-sm bg-white/5 px-3 py-1.5 rounded-lg border border-white/10">
            <Timer size={14} className="text-indigo-400" />
            {formatTime(seconds)}
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={runCode}
              disabled={isRunning || isSubmitting}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10 transition-all font-medium disabled:opacity-50"
            >
              {isRunning ? <Loader2 className="animate-spin" size={16} /> : <Play size={16} />}
              Run Code
            </button>
            <button 
              onClick={submitCode}
              disabled={isRunning || isSubmitting}
              className="flex items-center gap-2 px-6 py-2 rounded-xl bg-indigo-500 text-white hover:bg-indigo-600 transition-all font-bold shadow-lg shadow-indigo-500/20 disabled:opacity-50"
            >
              {isSubmitting ? <Loader2 className="animate-spin" size={16} /> : <Send size={16} />}
              Submit
            </button>
          </div>
          <button className="p-2 hover:bg-white/5 rounded-lg transition-colors text-slate-400">
            <Settings size={20} />
          </button>
        </div>
      </div>

      {/* Main content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel: Description */}
        <div className="w-[450px] border-r border-white/5 bg-[#0d0d14] flex flex-col shrink-0">
          <div className="flex border-b border-white/5">
            <button 
              onClick={() => setActiveTab('description')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-bold transition-all ${
                activeTab === 'description' ? "text-indigo-400 bg-indigo-500/5 border-b-2 border-indigo-500" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <Brain size={14} /> Description
            </button>
            <button 
              onClick={() => setActiveTab('feedback')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-bold transition-all relative ${
                activeTab === 'feedback' ? "text-indigo-400 bg-indigo-500/5 border-b-2 border-indigo-500" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <Award size={14} /> AI Review
              {feedback && <span className="absolute top-2 right-4 w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <AnimatePresence mode="wait">
              {activeTab === 'description' ? (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="space-y-6"
                >
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 bg-white/5 px-2 py-1 rounded border border-white/5 uppercase tracking-wider">
                      <Tag size={10} className="text-indigo-400" /> {challenge?.category}
                    </span>
                    {challenge?.companyTags?.map(tag => (
                      <span key={tag} className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 bg-white/5 px-2 py-1 rounded border border-white/5 uppercase tracking-wider">
                        <Building2 size={10} /> {tag}
                      </span>
                    ))}
                  </div>

                  <div className="prose prose-invert max-w-none">
                    <ReactMarkdown>{challenge?.description || ""}</ReactMarkdown>
                  </div>

                  {challenge?.constraints && (
                    <div className="space-y-3 pt-6 border-t border-white/5">
                      <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Constraints</h4>
                      <ul className="list-disc list-inside text-sm text-slate-400 space-y-1">
                        {challenge.constraints.map((c, i) => <li key={i}>{c}</li>)}
                      </ul>
                    </div>
                  )}
                </motion.div>
              ) : activeTab === 'feedback' ? (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="space-y-6"
                >
                  {!feedback ? (
                    <div className="text-center py-20 text-slate-500 bg-white/5 rounded-2xl border border-dashed border-white/10">
                      <Zap size={32} className="mx-auto mb-4 opacity-20" />
                      <p className="text-sm">Submit your code to receive <br />AI-powered feedback & optimizations.</p>
                    </div>
                  ) : (
                    <>
                      <div className="glass-card p-6 border-indigo-500/20 bg-indigo-500/5">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="text-lg font-bold text-indigo-400 font-mono">Expert Score</h4>
                          <span className="text-3xl font-black text-indigo-400">{feedback.score}/100</span>
                        </div>
                        <p className="text-slate-300 text-sm leading-relaxed">{feedback.summary}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Time complexity</p>
                          <p className="text-sm font-mono text-emerald-400">{feedback.timeComplexity || "O(N)"}</p>
                        </div>
                        <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Space complexity</p>
                          <p className="text-sm font-mono text-blue-400">{feedback.spaceComplexity || "O(1)"}</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Optimizations</h4>
                        <div className="space-y-2">
                          {feedback.optimizations?.map((opt: string, i: number) => (
                            <div key={i} className="flex gap-3 text-sm text-slate-400 bg-white/5 p-3 rounded-lg border border-white/5">
                              <TrendingUp size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                              <p>{opt}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <button 
                        onClick={downloadReport}
                        className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-white/10 hover:bg-white/5 transition-all text-sm font-bold text-slate-400"
                      >
                        <Download size={16} />
                        Download Assessment Report
                      </button>
                    </>
                  )}
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>
        </div>

        {/* Right Panel: Editor & Console */}
        <div className="flex-1 flex flex-col bg-[#11111a]">
          <div className="flex-1 relative border-b border-white/5">
            <div className="absolute top-4 right-6 z-10">
              <select 
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              >
                <option value="javascript">JavaScript</option>
                <option value="python">Python</option>
                <option value="cpp">C++</option>
                <option value="java">Java</option>
              </select>
            </div>
            <Editor
              height="100%"
              theme="vs-dark"
              language={language}
              value={code}
              onChange={(value) => setCode(value || "")}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                fontFamily: "'JetBrains Mono', monospace",
                lineNumbers: "on",
                scrollBeyondLastLine: false,
                automaticLayout: true,
                padding: { top: 20 }
              }}
            />
          </div>

          {/* Bottom Console */}
          <div className="h-1/3 min-h-[150px] flex flex-col bg-[#0d0d14]">
            <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 bg-white/5">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Console Output</span>
              <button onClick={() => setOutput(null)} className="text-xs text-slate-500 hover:text-slate-300">Clear</button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 font-mono text-sm">
              {!output ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-600 gap-2">
                  <Play size={20} className="opacity-20" />
                  <p>Run your code to see the test output.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className={`flex items-center gap-2 ${output.isCorrect ? "text-emerald-400" : "text-rose-400"}`}>
                    {output.isCorrect ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                    <span className="font-bold">{output.isCorrect ? "Submission Accepted" : "Compile/Runtime Fail"}</span>
                  </div>
                  <div className="bg-black/40 p-4 rounded-lg border border-white/5 text-slate-300 whitespace-pre-wrap">
                    {output.summary}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodeAssessment;

