import React from "react";
import { motion } from "motion/react";
import { useAuth } from "../context/AuthContext";
import { Navigate, Link } from "react-router-dom";
import { 
  BrainCircuit, 
  ChevronRight, 
  CheckCircle2, 
  Play, 
  Star,
  Zap,
  Shield,
  MessageSquare,
  Mic2,
  FileText,
  Mail,
  Send,
  User as UserIcon
} from "lucide-react";

const LandingPage = () => {
  const [inquiryForm, setInquiryForm] = React.useState({
    name: "",
    email: "",
    subject: "General Inquiry",
    message: ""
  });
  const [formStatus, setFormStatus] = React.useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleInquiryChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setInquiryForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    
    // Mock submission logic
    setTimeout(() => {
      setFormStatus('success');
      setInquiryForm({ name: "", email: "", subject: "General Inquiry", message: "" });
    }, 1000);
  };

  return (
    <div className="bg-slate-950 min-h-screen text-slate-200 overflow-x-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 glass backdrop-blur-2xl border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center">
              <BrainCircuit className="text-white" size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight gradient-text">TalentAI</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-400">
            <a href="#features" className="hover:text-slate-200 transition-colors">Features</a>
            <a href="#contact" className="hover:text-slate-200 transition-colors">Contact</a>
            <a href="#pricing" className="hover:text-slate-200 transition-colors">Pricing</a>
          </div>
          <div className="flex items-center gap-4">
            <Link 
              to="/login"
              className="text-sm font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Sign In
            </Link>
            <Link 
              to="/login"
              className="btn-primary flex items-center gap-2"
            >
              Get Started <ChevronRight size={18} />
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-40 pb-20 px-6 overflow-hidden">
        <div className="blur-blob w-[600px] h-[600px] bg-indigo-500 top-[-200px] right-[-100px]" />
        <div className="blur-blob w-[600px] h-[600px] bg-purple-500 bottom-[0px] left-[-200px]" />

        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold mb-6 uppercase tracking-widest">
              <Zap size={14} /> AI-Powered Career Coach
            </div>
            <h1 className="text-6xl md:text-7xl font-bold leading-tight mb-8">
              Master Your Next <span className="gradient-text">Interview</span> with AI.
            </h1>
            <p className="text-xl text-slate-400 mb-10 leading-relaxed max-w-xl">
              Professional mock interviews, real-time feedback, and resume optimization to help you land your dream job at top tech companies.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/login" className="btn-primary text-lg px-8 py-4">
                Start Practicing Free
              </Link>
              <button className="btn-outline text-lg px-8 py-4 flex items-center gap-2">
                <Play size={18} fill="currentColor" /> Watch Demo
              </button>
            </div>
            
            <div className="mt-12 flex items-center gap-6">
              <div className="flex -space-x-4">
                {[1,2,3,4].map(i => (
                  <img key={i} src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`} className="w-10 h-10 rounded-full border-2 border-slate-950" alt="user" />
                ))}
              </div>
              <p className="text-sm text-slate-500">
                <span className="text-slate-200 font-bold">10k+</span> students & pros trust TalentAI
              </p>
            </div>
          </motion.div>

          {/* Feature Card Mockup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="glass-card p-1 aspect-video rounded-3xl overflow-hidden group shadow-2xl">
              <div className="w-full h-full bg-slate-900 rounded-3xl flex flex-col items-center justify-center p-8 gap-6 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-500/10 to-transparent pointer-events-none" />
                <div className="w-20 h-20 bg-indigo-600 rounded-2xl flex items-center justify-center animate-bounce shadow-2xl shadow-indigo-500/50">
                  <Mic2 className="text-white" size={40} />
                </div>
                <div className="text-center">
                  <h3 className="text-2xl font-bold mb-2">Analyzing Pitch...</h3>
                  <div className="flex gap-1 justify-center">
                    {[1,2,3,4,3,2,1,2,3,2,1].map((h, i) => (
                      <motion.div 
                        key={i}
                        animate={{ height: [10, h * 10, 10] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.1 }}
                        className="w-1 bg-indigo-500 rounded-full" 
                        style={{ height: '20px' }}
                      />
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 w-full mt-4">
                  <div className="glass-card p-3 rounded-xl border-white/5">
                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Clarity</p>
                    <p className="text-lg font-bold">92%</p>
                  </div>
                  <div className="glass-card p-3 rounded-xl border-white/5">
                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Confidence</p>
                    <p className="text-lg font-bold text-emerald-400">High</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Floaties */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -top-10 -right-10 glass-card px-4 py-2 border border-white/10 flex items-center gap-2"
            >
              <Star className="text-yellow-400 fill-yellow-400" size={16} />
              <span className="text-sm font-bold">Gemini 3.0 Pro Powered</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 px-6 bg-slate-900/50">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Elite Interview <span className="gradient-text">Toolkit</span></h2>
          <p className="text-slate-400 max-w-2xl mx-auto">Everything you need to transform from a candidate to a top choice.</p>
        </div>

        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-8">
          {[
            { 
              icon: BrainCircuit, 
              title: "AI Simulations", 
              desc: "Role-specific interviews that adapt to your answers in real-time." 
            },
            { 
              icon: MessageSquare, 
              title: "Instant Feedback", 
              desc: "Get scored on clarity, tone, and technical accuracy immediately after each session." 
            },
            { 
              icon: FileText, 
              title: "Resume Audit", 
              desc: "AI analysis of your resume with tips to beat ATS systems and catch hiring managers' eyes." 
            },
            { 
              icon: Zap, 
              title: "Rapid Training", 
              desc: "Short, focused drills for difficult behavioral questions and technical deep dives." 
            },
            { 
              icon: Shield, 
              title: "Safe Environment", 
              desc: "Experiment and make mistakes in a zero-pressure environment before the real thing." 
            },
            { 
              icon: CheckCircle2, 
              title: "Report Cards", 
              desc: "Detailed progress tracking and performance analytics to identify weak points." 
            }
          ].map((f, i) => (
            <div key={i} className="glass-card border-white/5 hover:border-indigo-500/30">
              <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center mb-6 text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-all">
                <f.icon size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3">{f.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 px-6 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-600/5 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-bold mb-6">Have Questions? <br /><span className="gradient-text">Get in Touch</span></h2>
            <p className="text-slate-400 text-lg mb-8 leading-relaxed">
              Whether you're curious about our features, enterprise pricing, or just want to say hello, our team is ready to help you supercharge your career.
            </p>
            
            <div className="space-y-6">
              {[
                { icon: Mail, label: "Email as at", value: "hello@talentai.com" },
                { icon: MessageSquare, label: "Live Chat", value: "Available 24/7" },
                { icon: Shield, label: "Enterprise Support", value: "Dedicated support team" }
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-indigo-400">
                    <item.icon size={20} />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">{item.label}</p>
                    <p className="text-slate-200 font-medium">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-8 border-white/5 relative z-10">
            <form onSubmit={handleInquirySubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-400">Full Name</label>
                  <div className="relative">
                    <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                    <input 
                      type="text" 
                      name="name"
                      required
                      value={inquiryForm.name}
                      onChange={handleInquiryChange}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" 
                      placeholder="John Doe"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-400">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                    <input 
                      type="email" 
                      name="email"
                      required
                      value={inquiryForm.email}
                      onChange={handleInquiryChange}
                      className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" 
                      placeholder="john@example.com"
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-400">Subject</label>
                <select 
                  name="subject"
                  value={inquiryForm.subject}
                  onChange={handleInquiryChange}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-slate-200 focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all appearance-none"
                >
                  <option value="General Inquiry" className="bg-slate-900">General Inquiry</option>
                  <option value="Career Coaching" className="bg-slate-900">Career Coaching</option>
                  <option value="Enterprise Solution" className="bg-slate-900">Enterprise Solution</option>
                  <option value="Technical Support" className="bg-slate-900">Technical Support</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-400">Message</label>
                <textarea 
                  name="message"
                  required
                  rows={4}
                  value={inquiryForm.message}
                  onChange={handleInquiryChange}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-slate-200 focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all resize-none" 
                  placeholder="How can we help you?"
                />
              </div>

              {formStatus === 'success' && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm flex items-center gap-3">
                  <CheckCircle2 size={18} />
                  Thank you! Your message has been sent successfully.
                </div>
              )}

              {formStatus === 'error' && (
                <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm flex items-center gap-3">
                  <Shield size={18} />
                  There was an error sending your message. Please try again.
                </div>
              )}

              <button 
                type="submit" 
                disabled={formStatus === 'submitting'}
                className="w-full btn-primary py-4 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {formStatus === 'submitting' ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>Send Message <Send size={18} /></>
                )}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <BrainCircuit className="text-white" size={18} />
            </div>
            <span className="text-lg font-bold tracking-tight">TalentAI</span>
          </div>
          <p className="text-slate-500 text-sm">© 2026 TalentAI. Built for future leaders.</p>
          <div className="flex gap-6">
            <a href="#" className="text-slate-500 hover:text-indigo-400 transition-colors">Twitter</a>
            <a href="#" className="text-slate-500 hover:text-indigo-400 transition-colors">LinkedIn</a>
            <a href="#" className="text-slate-500 hover:text-indigo-400 transition-colors">GitHub</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
