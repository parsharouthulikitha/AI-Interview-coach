import React, { useState, useEffect } from "react";
import { 
  Code2, 
  Search, 
  Filter, 
  ChevronRight, 
  Star,
  Brain,
  Timer,
  Trophy,
  Plus,
  Sparkles,
  Tag,
  Building2,
  RefreshCw
} from "lucide-react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { INITIAL_CHALLENGES } from "../constants/challenges";

const CodingDashboard = () => {
  const [challenges, setChallenges] = useState<any[]>(INITIAL_CHALLENGES);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [generating, setGenerating] = useState(false);

  const categories = ["all", ...new Set(INITIAL_CHALLENGES.map(c => c.category))];

  const generateAIChallenge = async () => {
    setGenerating(true);
    // Future AI generation logic can go here
    setTimeout(() => {
      setGenerating(false);
      alert("AI Generation is currently unavailable while backend is being reset.");
    }, 1000);
  };

  const filteredChallenges = challenges.filter(c => 
    (c.title.toLowerCase().includes(search.toLowerCase()) || 
     c.category.toLowerCase().includes(search.toLowerCase())) &&
    (filter === "all" || c.difficulty === filter) &&
    (categoryFilter === "all" || c.category === categoryFilter)
  );

  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-20">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-bold mb-2">Coding <span className="gradient-text">Challenges</span></h1>
          <p className="text-slate-400">Master your technical skills with the most comprehensive collection of interview questions.</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="flex items-center gap-2 bg-indigo-500/10 border border-indigo-500/20 px-4 py-2 rounded-full text-indigo-400 text-sm font-medium">
            <Trophy size={16} />
            <span>Solves: 124</span>
            <div className="w-px h-3 bg-indigo-500/30 mx-2" />
            <Star size={16} className="fill-indigo-400" />
            <span>Points: 2,450</span>
          </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 shadow-lg shadow-emerald-500/10">
            <Brain size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Mastery Level</p>
            <p className="text-2xl font-bold">Advanced</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 shadow-lg shadow-blue-500/10">
            <Timer size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Avg. Solve Time</p>
            <p className="text-2xl font-bold">18m 24s</p>
          </div>
        </div>
        <div className="glass-card flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 shadow-lg shadow-purple-500/10">
            <Code2 size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Daily Streak</p>
            <p className="text-2xl font-bold">7 Days 🔥</p>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col gap-4 bg-white/5 p-6 rounded-2xl border border-white/10">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input 
              type="text" 
              placeholder="Search challenges by title, category, or company..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
          </div>
          <div className="flex gap-2">
            <select 
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-slate-400 text-sm focus:outline-none ring-offset-bg focus:ring-2 focus:ring-indigo-500/50"
            >
              {categories.map(c => (
                <option key={c} value={c} className="bg-slate-900">{c === 'all' ? 'All Topics' : c}</option>
              ))}
            </select>
            <div className="flex p-1 bg-white/5 rounded-xl border border-white/10">
              {["all", "easy", "medium", "hard"].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                    filter === f 
                      ? "bg-indigo-500 text-white shadow-lg shadow-indigo-500/20" 
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Challenges List */}
      <div className="grid gap-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-slate-400">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500 mb-4" />
            <p>Loading your curriculum...</p>
          </div>
        ) : filteredChallenges.length > 0 ? (
          filteredChallenges.map((challenge, idx) => (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={challenge.id}
              className="glass-card group hover:border-indigo-500/30 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 blur-3xl -translate-y-16 translate-x-16 group-hover:bg-indigo-500/10 transition-colors" />
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
                <div className="flex gap-6 items-start">
                  <div className={`w-14 h-14 shrink-0 rounded-2xl flex items-center justify-center text-xl font-bold shadow-inner ${
                    challenge.difficulty === 'easy' ? 'bg-emerald-500/10 text-emerald-500' :
                    challenge.difficulty === 'medium' ? 'bg-amber-500/10 text-amber-500' :
                    'bg-rose-500/10 text-rose-500'
                  }`}>
                    {challenge.title.charAt(0)}
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-xl font-bold group-hover:text-indigo-400 transition-colors">{challenge.title}</h3>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        challenge.difficulty === 'easy' ? 'bg-emerald-500/10 text-emerald-400' :
                        challenge.difficulty === 'medium' ? 'bg-amber-500/10 text-amber-400' :
                        'bg-rose-500/10 text-rose-400'
                      }`}>
                        {challenge.difficulty}
                      </span>
                    </div>
                    <p className="text-slate-400 text-sm line-clamp-1 max-w-2xl">{challenge.description}</p>
                    
                    <div className="flex flex-wrap items-center gap-4 text-xs">
                       <span className="flex items-center gap-1.5 text-slate-500 bg-white/5 px-2 py-1 rounded-md border border-white/5">
                         <Tag size={12} className="text-indigo-400" /> {challenge.category}
                       </span>
                       {challenge.companyTags && challenge.companyTags.length > 0 && (
                         <div className="flex items-center gap-2">
                            <Building2 size={12} className="text-slate-500" />
                            {challenge.companyTags.map((tag: string) => (
                              <span key={tag} className="text-slate-500 hover:text-slate-300 transition-colors">{tag}</span>
                            ))}
                         </div>
                       )}
                       <div className="h-3 w-px bg-white/10 mx-1" />
                       <span className="flex items-center gap-1.5 text-slate-500">
                         <Code2 size={12} /> {challenge.stats?.solves?.toLocaleString() || 0} Solved
                       </span>
                       <span className="flex items-center gap-1.5 text-amber-400">
                         <Star size={12} className="fill-amber-400" /> {challenge.stats?.rating || 0}
                       </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Link 
                    to={`/code-assessment/${challenge.id}`}
                    className="btn-primary py-2.5 px-8 flex items-center gap-2 group/btn whitespace-nowrap shadow-xl shadow-indigo-500/10"
                  >
                    Solve Now
                    <ChevronRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-24 bg-white/5 rounded-3xl border border-dashed border-white/10">
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
              <Code2 size={32} className="text-slate-500" />
            </div>
            <h3 className="text-2xl font-bold text-slate-300 mb-2">No matching challenges</h3>
            <p className="text-slate-500 max-w-sm mx-auto">We couldn't find any questions matching your filters. Try clearing them or use the AI generator.</p>
            <button 
              onClick={() => { setSearch(""); setFilter("all"); setCategoryFilter("all"); }}
              className="mt-6 text-indigo-400 font-bold hover:text-indigo-300 transition-colors"
            >
              Clear all filters
            </button>
          </div>
        )}
      </div>

      {/* AI Generation Section */}
      <div className="relative pt-12">
        <div className="absolute inset-0 flex items-center" aria-hidden="true">
          <div className="w-full border-t border-white/5"></div>
        </div>
        <div className="relative flex justify-center">
          <span className="bg-[#0a0a0f] px-6 text-sm font-bold text-slate-500 uppercase tracking-[0.2em] flex items-center gap-2">
            <Sparkles size={16} className="text-indigo-400" /> DeepMind AI Labs
          </span>
        </div>
      </div>

      <div className="bg-gradient-to-br from-indigo-500/10 to-purple-500/5 rounded-3xl border border-indigo-500/20 p-8 md:p-12 text-center space-y-6 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-500/10 blur-[120px] -translate-y-1/2 translate-x-1/4 rounded-full" />
        <div className="relative z-10 space-y-4 max-w-2xl mx-auto">
          <h2 className="text-3xl font-bold">Limited by candidates? <span className="gradient-text">Generate unique problems.</span></h2>
          <p className="text-slate-400 text-lg">Use our proprietary AI model to generate unique coding challenges tailored to specific tech stacks and seniority levels.</p>
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={generateAIChallenge}
              disabled={generating}
              className="flex items-center gap-3 px-8 py-3.5 rounded-2xl bg-indigo-500 hover:bg-indigo-600 text-white font-bold transition-all shadow-2xl shadow-indigo-500/30 disabled:opacity-50"
            >
              {generating ? <RefreshCw size={20} className="animate-spin" /> : <Sparkles size={20} />}
              Generate AI Interview Problem
            </button>
            <button className="text-sm font-bold text-slate-400 hover:text-white transition-colors">
              Customize problem params →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodingDashboard;

