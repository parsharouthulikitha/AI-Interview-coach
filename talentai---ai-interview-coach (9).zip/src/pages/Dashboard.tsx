import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import { 
  TrendingUp, 
  Users, 
  Clock, 
  Award,
  ChevronRight,
  PlusCircle,
  ArrowUpRight,
  Code2,
  Trophy,
  Video,
  Github,
  Linkedin,
  Link as LinkIcon
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Link } from "react-router-dom";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";

const Dashboard = () => {
  const { user } = useAuth();
  const [recentSessions] = useState<any[]>([]);
  const [recentSubmissions] = useState<any[]>([]);
  const [stats] = useState({
    totalInterviews: 0,
    avgScore: 0,
    timeSpent: "0h",
    topMetric: "Communication",
    codingSolves: 0
  });

  const data = [
    { name: 'Mon', score: 65 },
    { name: 'Tue', score: 70 },
    { name: 'Wed', score: 75 },
    { name: 'Thu', score: 72 },
    { name: 'Fri', score: 85 },
    { name: 'Sat', score: 82 },
    { name: 'Sun', score: 90 },
  ];

  return (
    <div className="space-y-10">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2">Welcome back, <span className="gradient-text">{user?.name || "User"}</span>!</h1>
          <p className="text-slate-400">Ready to sharpen your skills today? Your progress is looking sharp.</p>
        </div>
        <Link to="/interview" className="btn-primary flex items-center gap-2">
          <PlusCircle size={20} /> New Mock Interview
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: "Total Sessions", value: stats.totalInterviews, icon: Video, color: "text-blue-400", bg: "bg-blue-500/10" },
          { label: "Coding Solves", value: stats.codingSolves, icon: Code2, color: "text-emerald-400", bg: "bg-emerald-500/10" },
          { label: "Avg. Performance", value: `${stats.avgScore}%`, icon: TrendingUp, color: "text-indigo-400", bg: "bg-indigo-500/10" },
          { label: "Prep Time", value: stats.timeSpent, icon: Clock, color: "text-purple-400", bg: "bg-purple-500/10" },
        ].map((stat, i) => (
          <div key={i} className="glass-card flex items-center gap-4">
            <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-xl flex items-center justify-center`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
              <p className="text-2xl font-bold">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Progress Chart */}
        <div className="lg:col-span-2 glass-card p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-xl font-bold">Improvement Over Time</h3>
              <p className="text-sm text-slate-500">Weekly performance tracking</p>
            </div>
            <select className="bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-slate-300">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #ffffff10', borderRadius: '12px' }}
                  itemStyle={{ color: '#818cf8' }}
                />
                <Area type="monotone" dataKey="score" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorScore)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Industry Trends */}
        <div className="space-y-8">
          <div className="glass-card p-8 bg-indigo-500/5 border-indigo-500/20">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Code2 size={20} className="text-indigo-400" />
                Latest Solves
              </h3>
              <Trophy size={18} className="text-amber-500" />
            </div>
            <div className="space-y-4">
              {recentSubmissions.length > 0 ? recentSubmissions.map((sub, i) => (
                <div key={sub.id} className="p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 transition-all">
                  <div className="flex justify-between items-start mb-1">
                    <p className="text-sm font-bold truncate pr-2">{sub.challengeTitle}</p>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                      sub.status === 'accepted' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
                    }`}>
                      {sub.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: `${sub.feedback?.score || 0}%` }} />
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">{sub.feedback?.score}%</span>
                  </div>
                </div>
              )) : (
                <p className="text-center py-6 text-sm text-slate-500">No coding solutions yet.</p>
              )}
            </div>
            <Link to="/coding-dashboard" className="w-full mt-6 btn-secondary py-2.5 text-xs text-center flex items-center justify-center gap-2">
              Explore Questions <ChevronRight size={14} />
            </Link>
          </div>

          <div className="glass-card p-8 bg-gradient-to-br from-indigo-500/10 to-purple-500/10 border-indigo-500/20">
            <h3 className="text-xl font-bold mb-4">Professional Profile</h3>
            <p className="text-sm text-slate-400 mb-6">Connect GitHub and LinkedIn to unlock personalized AI coaching.</p>
            <div className="flex gap-4 mb-6">
              <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-slate-400">
                <Github size={18} />
              </div>
              <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-slate-400">
                <Linkedin size={18} />
              </div>
            </div>
            <Link to="/integrations" className="w-full btn-primary py-3 text-sm flex items-center justify-center gap-2">
              Connect Profiles <ChevronRight size={14} />
            </Link>
          </div>

          <div className="glass-card p-8">
            <h3 className="text-xl font-bold mb-6">Hot Skills for You</h3>
          <div className="space-y-6">
            {[
              { skill: "System Design", demand: "High", growth: "+12%" },
              { skill: "Cloud Architecture", demand: "Critical", growth: "+18%" },
              { skill: "React Native", demand: "Medium", growth: "+5%" },
              { skill: "LLM Orchestration", demand: "Rising", growth: "+45%" },
            ].map((skill, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                <div>
                  <p className="font-semibold">{skill.skill}</p>
                  <p className="text-xs text-slate-500">Demand: {skill.demand}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-emerald-400 flex items-center justify-end gap-1">
                    {skill.growth} <TrendingUp size={14} />
                  </p>
                  <p className="text-[10px] text-slate-500 uppercase tracking-wider">Growth</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 rounded-xl border border-white/10 text-slate-400 text-sm hover:text-slate-200 hover:bg-white/5 transition-all">
            View Market Intelligence
          </button>
        </div>
      </div>
    </div>

      {/* Recent Sessions List */}
      <div className="glass-card overflow-hidden">
        <div className="px-8 py-6 border-b border-white/5 flex justify-between items-center">
          <h3 className="text-xl font-bold">Recent Interviews</h3>
          <button className="text-indigo-400 text-sm hover:underline flex items-center gap-1">
            View All <ChevronRight size={16} />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-white/5 text-slate-500 text-xs uppercase tracking-widest font-bold">
                <th className="px-8 py-4">Role & Session</th>
                <th className="px-8 py-4">Status</th>
                <th className="px-8 py-4">Score</th>
                <th className="px-8 py-4">Date</th>
                <th className="px-8 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {recentSessions.length > 0 ? (
                recentSessions.map((session) => (
                  <tr key={session.id} className="hover:bg-white/5 transition-colors group">
                    <td className="px-8 py-6">
                      <p className="font-bold text-slate-200 capitalize">{session.role || "General"}</p>
                      <p className="text-xs text-slate-500">{session.type} Interview</p>
                    </td>
                    <td className="px-8 py-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        session.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'
                      }`}>
                        {session.status}
                      </span>
                    </td>
                    <td className="px-8 py-6 font-mono text-lg font-bold">
                      {session.score || "--"}%
                    </td>
                    <td className="px-8 py-6 text-sm text-slate-400">
                      {session.created_at ? new Date(session.created_at).toLocaleDateString() : "Today"}
                    </td>
                    <td className="px-8 py-6 text-right">
                      <button className="p-2 rounded-lg bg-white/5 group-hover:bg-indigo-500 group-hover:text-white transition-all">
                        <ArrowUpRight size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-8 py-20 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center text-slate-600">
                        <Clock size={32} />
                      </div>
                      <p className="text-slate-500">No interviews yet. Ready to start your first one?</p>
                      <Link to="/interview" className="btn-outline">Start Practicing</Link>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
