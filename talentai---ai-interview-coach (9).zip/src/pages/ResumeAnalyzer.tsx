import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, 
  Upload, 
  Search, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Loader2,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Zap,
  Star,
  Linkedin
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

const ResumeAnalyzer = () => {
  const { user } = useAuth();
  const [resumeText, setResumeText] = useState("");
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'results'>('upload');
  const [hasLinkedin] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    // Integration checking removed
  }, [user]);

  const handleLinkedinSync = async () => {
    setSyncing(true);
    setTimeout(() => {
      setResumeText(prev => prev + `\n\n[LINKEDIN IMPORT UNAVAILABLE]\nExperience: Senior Developer at TechCorp (2020-Present)`);
      setSyncing(false);
    }, 1000);
  };

  const handleAnalyze = async () => {
    if (!resumeText.trim()) return;

    setLoading(true);
    try {
      const res = await fetch("/api/ai/analyze-resume", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText }),
      });
      if (!res.ok) throw new Error("Analysis failed");
      const data = await res.json();
      setAnalysis(data);
      setActiveTab('results');
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setResumeText(event.target?.result as string);
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-10">
      <div className="text-left">
        <h1 className="text-4xl font-bold mb-4">Resume <span className="gradient-text">Analyzer</span></h1>
        <p className="text-slate-400">Optimize your resume with AI to beat applicant tracking systems and stand out.</p>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'upload' ? (
          <motion.div 
            key="upload"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Text Input */}
              <div className="glass-card p-8 flex flex-col gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-indigo-500/20 text-indigo-400 rounded-lg flex items-center justify-center">
                    <FileText size={20} />
                  </div>
                  <h3 className="text-xl font-bold">Paste Resume Text</h3>
                </div>
                <div className="flex-1 relative flex flex-col">
                  {hasLinkedin && (
                    <button 
                      onClick={handleLinkedinSync}
                      disabled={syncing}
                      className="absolute top-4 right-4 z-10 flex items-center gap-2 px-3 py-1.5 bg-blue-600/10 text-blue-400 border border-blue-600/20 rounded-lg text-xs font-bold hover:bg-blue-600/20 transition-all"
                    >
                      {syncing ? <Loader2 size={14} className="animate-spin" /> : <Linkedin size={14} />}
                      Sync from LinkedIn
                    </button>
                  )}
                  <textarea 
                    value={resumeText}
                    onChange={e => setResumeText(e.target.value)}
                    placeholder="Paste your professional summary, experience, and skills here..."
                    className="flex-1 min-h-[400px] w-full bg-black/20 border border-white/5 rounded-2xl p-6 text-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none font-sans leading-relaxed pt-14"
                  />
                </div>
              </div>

              {/* Sidebar Info & Upload */}
              <div className="space-y-6">
                <div className="glass-card p-8">
                  <div className="text-center space-y-6">
                    <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto text-slate-400 border border-dashed border-white/20 group hover:border-indigo-400 transition-all cursor-pointer relative">
                      <input 
                        type="file" 
                        accept=".txt,.md,.pdf" 
                        onChange={handleFileUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                      />
                      <Upload size={32} />
                    </div>
                    <div>
                      <h4 className="font-bold">Upload Document</h4>
                      <p className="text-xs text-slate-500 mt-1">Supports .txt, .md (PDF text coming soon)</p>
                    </div>
                  </div>
                </div>

                <div className="glass-card p-8 space-y-6">
                  <h4 className="font-bold text-sm uppercase tracking-widest text-slate-500">Analysis Features</h4>
                  <ul className="space-y-4">
                    {[
                      { icon: ShieldCheck, text: "ATS Compatibility Scan", color: "text-emerald-400" },
                      { icon: Zap, text: "Impact Phrase Suggestions", color: "text-amber-400" },
                      { icon: Star, text: "Role-specific Tailoring", color: "text-indigo-400" },
                      { icon: Search, text: "Clarity & Readability Audit", color: "text-blue-400" }
                    ].map((item, i) => (
                      <li key={i} className="flex items-center gap-4 text-sm text-slate-300">
                        <item.icon size={20} className={item.color} />
                        {item.text}
                      </li>
                    ))}
                  </ul>
                </div>

                <button 
                  onClick={handleAnalyze}
                  disabled={loading || !resumeText.trim()}
                  className="w-full btn-primary h-16 text-lg flex items-center justify-center gap-3 shadow-indigo-500/40"
                >
                  {loading ? <Loader2 className="animate-spin" /> : <><Sparkles size={20} /> Deep AI Audit</>}
                </button>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="results"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="flex justify-between items-center">
              <button 
                onClick={() => setActiveTab('upload')}
                className="text-indigo-400 hover:underline flex items-center gap-2"
              >
                Back to Upload
              </button>
              <div className="flex gap-4">
                <button className="btn-outline px-4 py-2 text-sm">Download Report</button>
                <button className="btn-primary px-4 py-2 text-sm">Save Analysis</button>
              </div>
            </div>

            <div className="glass-card p-10 space-y-12">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold uppercase tracking-widest mb-2">
                  Executive Summary
                </div>
                <p className="text-xl text-slate-200 leading-relaxed font-medium">
                  {analysis?.summary}
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-10">
                <div className="space-y-6">
                  <h4 className="flex items-center gap-3 font-bold text-emerald-400 uppercase tracking-widest text-xs border-b border-white/5 pb-4">
                    <CheckCircle size={18} /> Major Strengths
                  </h4>
                  <ul className="space-y-4">
                    {analysis?.strengths?.map((item: string, i: number) => (
                      <li key={i} className="bg-white/5 p-4 rounded-xl text-slate-300 text-sm border-l-4 border-emerald-500">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-6">
                  <h4 className="flex items-center gap-3 font-bold text-amber-500 uppercase tracking-widest text-xs border-b border-white/5 pb-4">
                    <AlertCircle size={18} /> Strategic Weaknesses
                  </h4>
                  <ul className="space-y-4">
                    {analysis?.weaknesses?.map((item: string, i: number) => (
                      <li key={i} className="bg-white/5 p-4 rounded-xl text-slate-300 text-sm border-l-4 border-amber-500">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="bg-indigo-600/10 p-10 rounded-3xl border border-indigo-500/20 space-y-6">
                <h4 className="flex items-center gap-3 font-bold text-indigo-400 uppercase tracking-widest text-xs">
                  <Zap size={18} /> High-Impact Action Items
                </h4>
                <div className="grid md:grid-cols-2 gap-6">
                  {analysis?.suggestedImprovements?.map((item: string, i: number) => (
                    <div key={i} className="flex gap-4 items-start bg-white/5 p-5 rounded-2xl border border-white/5">
                      <div className="w-6 h-6 bg-indigo-500/20 text-indigo-400 rounded-full flex items-center justify-center shrink-0 font-bold text-xs">
                        {i + 1}
                      </div>
                      <p className="text-sm text-slate-300 leading-relaxed">{item}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="flex justify-center pt-8">
              <button 
                onClick={() => window.location.href = '/interview'}
                className="btn-primary group flex items-center gap-3 px-10 h-16 text-lg"
              >
                Proceed to Mock Interview
                <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ResumeAnalyzer;
