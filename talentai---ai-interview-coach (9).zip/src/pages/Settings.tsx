import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { 
  User, 
  Bell, 
  Shield, 
  CreditCard,
  Target,
  Briefcase,
  Save,
  Loader2
} from "lucide-react";

const Settings = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState({
    displayName: user?.email?.split('@')[0] || "",
    targetRole: "Senior Software Engineer",
    industry: "Tech",
    experienceLevel: "Senior",
    bio: ""
  });

  const handleSave = async () => {
    setLoading(true);
    // Placeholder for local persistence if needed
    setTimeout(() => {
      setLoading(false);
      alert("Settings saved locally (backend is currently reset).");
    }, 500);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-4xl font-bold mb-2">Account <span className="gradient-text">Settings</span></h1>
          <p className="text-slate-400">Manage your profile, preferences, and workspace settings.</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={loading}
          className="btn-primary flex items-center gap-2"
        >
          {loading ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
          Save Changes
        </button>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          {[
            { id: 'profile', label: 'Public Profile', icon: User },
            { id: 'experience', label: 'Career Targets', icon: Target },
            { id: 'notifications', label: 'Notifications', icon: Bell },
            { id: 'security', label: 'Security', icon: Shield },
            { id: 'billing', label: 'Plan & Billing', icon: CreditCard },
          ].map((item) => (
            <button 
              key={item.id}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                item.id === 'profile' ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20" : "text-slate-400 hover:bg-white/5"
              }`}
            >
              <item.icon size={18} />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="lg:col-span-2 space-y-8">
          {/* Profile Section */}
          <section className="glass-card p-8 space-y-6">
            <h3 className="text-xl font-bold border-b border-white/5 pb-4">Personal Information</h3>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
                <input 
                  type="text" 
                  value={profile.displayName}
                  onChange={e => setProfile({...profile, displayName: e.target.value})}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500/50" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Primary Email</label>
                <input 
                  type="email" 
                  value={user?.email || ""} 
                  disabled
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 opacity-50 cursor-not-allowed" 
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Short Bio</label>
              <textarea 
                value={profile.bio}
                onChange={e => setProfile({...profile, bio: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 h-32 resize-none"
                placeholder="Tell us about yourself..."
              />
            </div>
          </section>

          {/* Career Section */}
          <section className="glass-card p-8 space-y-6">
            <h3 className="text-xl font-bold border-b border-white/5 pb-4">Career Targets</h3>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Target Role</label>
                  <div className="relative">
                    <Briefcase className="absolute left-4 top-3 text-slate-500" size={18} />
                    <input 
                      type="text" 
                      value={profile.targetRole}
                      onChange={e => setProfile({...profile, targetRole: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-12 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50" 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Industry</label>
                  <input 
                    type="text" 
                    value={profile.industry}
                    onChange={e => setProfile({...profile, industry: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50" 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Experience Level</label>
                <select 
                  value={profile.experienceLevel}
                  onChange={e => setProfile({...profile, experienceLevel: e.target.value})}
                  className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                >
                  <option>Entry Level</option>
                  <option>Mid Level</option>
                  <option>Senior</option>
                  <option>Principal / Lead</option>
                  <option>Executive</option>
                </select>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Settings;
