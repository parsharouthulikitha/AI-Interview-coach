import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Github, 
  Linkedin, 
  CheckCircle2, 
  ExternalLink, 
  RefreshCw, 
  ShieldCheck, 
  Code2, 
  Briefcase, 
  TrendingUp, 
  ChevronRight,
  Info,
  Database,
  XCircle
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

interface Repository {
  id: number;
  name: string;
  description: string;
  html_url: string;
  language: string;
  stargazers_count: number;
}

interface GithubProfile {
  login: string;
  avatar_url: string;
  bio: string;
  public_repos: number;
  followers: number;
}

const Integrations = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [integrations, setIntegrations] = useState<any>({
    github: { connected: false, token: null, data: null },
    linkedin: { connected: false, token: null, data: null },
    supabase: { connected: false, status: 'idle' }
  });
  const [repos, setRepos] = useState<Repository[]>([]);
  const [syncing, setSyncing] = useState<string | null>(null);

  useEffect(() => {
    // Auth monitoring for OAuth popups would go here
  }, [user]);

  const fetchGithubRepos = async (token: string) => {
    setSyncing('github');
    try {
      const response = await fetch('https://api.github.com/user/repos?sort=updated&per_page=6', {
        headers: { Authorization: `token ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setRepos(data);
      }
    } catch (error) {
      console.error("Error fetching repos:", error);
    } finally {
      setSyncing(null);
    }
  };

  const testSupabaseConnection = async () => {
    setSyncing('supabase');
    setTimeout(() => {
      setSyncing(null);
      alert("Supabase verification is currently unavailable while backend is being reset.");
    }, 1000);
  };

  const connectService = async (provider: string) => {
    alert(`${provider} integration is currently unavailable while backend is being reset.`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-80px)]">
        <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-10">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Professional Integrations</h1>
        <p className="text-slate-400">Connect your profiles to enhance your AI coaching and portfolio analysis.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* GitHub Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-8 space-y-6 relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Github size={120} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center text-white">
                <Github size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold">GitHub</h3>
                <p className="text-sm text-slate-400">Sync repositories and projects</p>
              </div>
            </div>
            {integrations.github.connected && (
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-400/10 px-3 py-1.5 rounded-full border border-emerald-400/20">
                <CheckCircle2 size={14} /> Connected
              </span>
            )}
          </div>

          <p className="text-slate-300 leading-relaxed">
            Import your public repositories to let our AI analyze your technical expertise, coding patterns, and project complexity. This data helps us generate more relevant technical interview questions.
          </p>

          {!integrations.github.connected ? (
            <button 
              onClick={() => connectService('github')}
              className="btn-primary w-full flex items-center justify-center gap-3 py-4 text-base"
            >
              <Github size={20} /> Connect GitHub Account
            </button>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-slate-400">Latest Repositories</span>
                <button 
                  onClick={() => fetchGithubRepos(integrations.github.token)}
                  disabled={syncing === 'github'}
                  className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                  <RefreshCw size={14} className={syncing === 'github' ? 'animate-spin' : ''} /> Sync Data
                </button>
              </div>
              <div className="grid grid-cols-1 gap-3">
                {repos.map(repo => (
                  <div key={repo.id} className="p-4 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between group/repo">
                    <div className="space-y-1">
                      <p className="font-bold text-slate-200">{repo.name}</p>
                      <div className="flex items-center gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1"><Code2 size={12} /> {repo.language || 'Plain Text'}</span>
                        <span className="flex items-center gap-1">★ {repo.stargazers_count}</span>
                      </div>
                    </div>
                    <a href={repo.html_url} target="_blank" rel="noopener noreferrer" className="opacity-0 group-hover/repo:opacity-100 transition-opacity">
                      <ExternalLink size={16} className="text-slate-400 hover:text-white" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>

        {/* LinkedIn Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card p-8 space-y-6 relative overflow-hidden group border-indigo-500/20"
        >
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Linkedin size={120} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white">
                <Linkedin size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold">LinkedIn</h3>
                <p className="text-sm text-slate-400">Import professional experience</p>
              </div>
            </div>
            {integrations.linkedin.connected && (
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-400/10 px-3 py-1.5 rounded-full border border-emerald-400/20">
                <CheckCircle2 size={14} /> Connected
              </span>
            )}
          </div>

          <p className="text-slate-300 leading-relaxed">
            Connect your LinkedIn profile to automatically sync your job history, certifications, and skills. Use this data to power our resume analyzer and get personalized interview feedback.
          </p>

          {!integrations.linkedin.connected ? (
            <button 
              onClick={() => connectService('linkedin')}
              className="w-full flex items-center justify-center gap-3 py-4 text-base font-bold bg-[#0077b5] hover:bg-[#005582] text-white rounded-2xl transition-all shadow-lg hover:shadow-[#0077b5]/20"
            >
              <Linkedin size={20} /> Connect LinkedIn Profile
            </button>
          ) : (
            <div className="p-6 rounded-2xl bg-indigo-500/5 border border-indigo-500/10 space-y-4">
              <div className="flex items-center gap-4">
                {integrations.linkedin.data?.profilePicture ? (
                  <img src={integrations.linkedin.data.profilePicture} className="w-12 h-12 rounded-full border-2 border-indigo-500/20" alt="Profile" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold">
                    {user?.name?.charAt(0) || 'G'}
                  </div>
                )}
                <div>
                  <p className="font-bold text-slate-200">Account Synced</p>
                  <p className="text-xs text-slate-400">Professional profile is up to date.</p>
                </div>
              </div>
              <div className="space-y-3 pt-4">
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <Briefcase size={16} />
                  </div>
                  Experience & Skills Synced
                </div>
                <div className="flex items-center gap-3 text-sm text-slate-300">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <TrendingUp size={16} />
                  </div>
                  Profile Analysis Ready
                </div>
              </div>
            </div>
          )}
        </motion.div>

        {/* Supabase Card */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card p-8 space-y-6 relative overflow-hidden group border-emerald-500/20"
        >
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <Database size={120} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-emerald-600 rounded-2xl flex items-center justify-center text-white">
                <Database size={32} />
              </div>
              <div>
                <h3 className="text-xl font-bold">Supabase</h3>
                <p className="text-sm text-slate-400">PostgreSQL Backend Integration</p>
              </div>
            </div>
            {integrations.supabase?.connected && (
              <span className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-400/10 px-3 py-1.5 rounded-full border border-emerald-400/20">
                <CheckCircle2 size={14} /> Active
              </span>
            )}
          </div>

          <p className="text-slate-300 leading-relaxed">
            Connect your Supabase project to enable advanced data features, custom database functions, and storage buckets. Once connected, the AI Coach can sync your session records to your own database.
          </p>

          {!integrations.supabase?.connected ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 flex gap-3">
                <Info size={18} className="text-amber-500 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-200/80">
                  Ensure you have added <code className="bg-black/40 px-1 rounded">VITE_SUPABASE_URL</code> and <code className="bg-black/40 px-1 rounded">VITE_SUPABASE_ANON_KEY</code> to your environment settings.
                </p>
              </div>
              <button 
                onClick={testSupabaseConnection}
                disabled={syncing === 'supabase'}
                className="btn-primary w-full flex items-center justify-center gap-3 py-4 text-base"
              >
                {syncing === 'supabase' ? <RefreshCw className="animate-spin" /> : <Database size={20} />} 
                Verify Supabase Connection
              </button>
              {integrations.supabase?.status === 'error' && (
                <p className="text-xs text-rose-400 flex items-center gap-1.5 justify-center">
                  <XCircle size={14} /> Connection failed. Check your environment variables.
                </p>
              )}
            </div>
          ) : (
            <div className="space-y-4">
               <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="text-emerald-500" size={18} />
                  <span className="text-sm font-medium text-emerald-100">Ready to sync</span>
                </div>
                <button 
                  onClick={testSupabaseConnection}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                >
                  <RefreshCw size={12} className={syncing === 'supabase' ? 'animate-spin' : ''} /> Re-verify
                </button>
              </div>
              <div className="text-xs text-slate-500 space-y-1">
                <p>Project URL: {import.meta.env.VITE_SUPABASE_URL?.substring(0, 30)}...</p>
                <p>Connected as: Anonymous Client</p>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Benefits Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { 
            icon: ShieldCheck, 
            label: "Secure Connection", 
            text: "Your data is encrypted and accessed only for coaching purposes.",
            color: "text-blue-400"
          },
          { 
            icon: TrendingUp, 
            label: "Enhanced AI Insights", 
            text: "Real profile data leads to 40% more accurate interview questions.",
            color: "text-emerald-400"
          },
          { 
            icon: Info, 
            label: "One-Click Sync", 
            text: "Keep your coaching profile updated with your latest achievements.",
            color: "text-amber-400"
          }
        ].map((benefit, i) => (
          <div key={i} className="glass-card p-6 flex flex-col items-center text-center space-y-3">
            <div className={`p-3 rounded-xl bg-white/5 ${benefit.color}`}>
              <benefit.icon size={24} />
            </div>
            <h4 className="font-bold">{benefit.label}</h4>
            <p className="text-sm text-slate-400">{benefit.text}</p>
          </div>
        ))}
      </div>

      {/* Footer CTA */}
      <div className="text-center pt-10">
        <p className="text-sm text-slate-500 mb-4 flex items-center justify-center gap-2">
          <ShieldCheck size={14} /> Our systems are fully GDPR compliant and secure.
        </p>
      </div>
    </div>
  );
};

export default Integrations;
