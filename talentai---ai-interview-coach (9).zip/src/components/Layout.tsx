import React from "react";
import { Link, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { 
  LayoutDashboard, 
  Mic2, 
  FileText, 
  Settings, 
  LogOut,
  BrainCircuit,
  Terminal,
  Share2
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { logout, user } = useAuth();
  const location = useLocation();

  const menuItems = [
    { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
    { icon: Mic2, label: "Mock Interview", path: "/interview" },
    { icon: Terminal, label: "Coding Challenges", path: "/coding-dashboard" },
    { icon: FileText, label: "Resume Analysis", path: "/resume" },
    { icon: Share2, label: "Integrations", path: "/integrations" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-200 overflow-hidden">
      {/* Background Blobs */}
      <div className="blur-blob w-[500px] h-[500px] bg-indigo-600 top-[-250px] left-[-250px]" />
      <div className="blur-blob w-[500px] h-[500px] bg-purple-600 bottom-[-250px] right-[-250px]" />

      {/* Sidebar */}
      <aside className="w-64 border-r border-white/5 flex flex-col glass backdrop-blur-2xl z-20">
        <div className="p-8 flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/50">
            <BrainCircuit className="text-white" size={24} />
          </div>
          <span className="text-xl font-bold tracking-tight gradient-text">TalentAI</span>
        </div>

        <nav className="flex-1 px-4 py-8">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                    location.pathname === item.path
                      ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shadow-[0_0_15px_rgba(99,102,241,0.1)]"
                      : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                  }`}
                >
                  <item.icon size={20} className={location.pathname === item.path ? "text-indigo-400" : "group-hover:text-slate-200"} />
                  <span className="font-medium">{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 border-t border-white/5">
          <div className="bg-white/5 rounded-2xl p-4 mb-4 flex items-center gap-3">
            <img 
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`} 
              alt="Avatar" 
              className="w-10 h-10 rounded-full border border-white/10"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">{user?.name || "Guest User"}</p>
              <p className="text-xs text-slate-500 truncate">{user?.email}</p>
            </div>
          </div>
          <button 
            onClick={logout}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all"
          >
            <LogOut size={18} />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-y-auto">
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-10 glass sticky top-0 z-10 backdrop-blur-3xl">
          <div className="flex items-center gap-3 text-slate-400">
            <Terminal size={18} />
            <span className="text-xs font-mono uppercase tracking-widest opacity-50">System Response: Optimal</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              AI Coach Online
            </div>
          </div>
        </header>
        
        <div className="flex-1 p-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {children}
          </motion.div>
        </div>
      </main>
    </div>
  );
};
