import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { Express } from "express";

export const setupSecurity = (app: Express) => {
  // Use Helmet for secure headers
  app.use(helmet({
    contentSecurityPolicy: false, // Disabled for development/vite compatibility
  }));

  // Enable CORS
  app.use(cors());

  // Rate limiting to prevent abuse
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Limit each IP to 100 requests per windowMs
    message: { error: "Too many requests, please try again later." }
  });

  // Apply limiter to all /api routes
  app.use("/api/", limiter);
};
