import { Router } from "express";
import { authController } from "../controllers/authController";

const router = Router();

router.get("/github/url", authController.getGithubAuthUrl);
router.get("/github/callback", authController.githubCallback);

router.get("/linkedin/url", authController.getLinkedinAuthUrl);
router.get("/linkedin/callback", authController.linkedinCallback);

export default router;
