import { Router } from "express";
import { aiController } from "../controllers/aiController";

const router = Router();

router.post("/questions", aiController.getQuestions);
router.post("/analyze-resume", aiController.analyzeResume);
router.post("/feedback", aiController.getFeedback);
router.post("/code-review", aiController.reviewCode);
router.post("/generate-challenge", aiController.generateChallenge);

export default router;
