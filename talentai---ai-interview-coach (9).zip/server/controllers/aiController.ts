import { Request, Response } from "express";
import { geminiService } from "../services/geminiService";

export const aiController = {
  async getQuestions(req: Request, res: Response) {
    try {
      const { role, industry, experience, count = 5 } = req.body;
      const prompt = `Generate ${count} professional interview questions for a ${experience} level ${role} in the ${industry} industry. Focus on a mix of technical and behavioral questions. Return as a JSON array of strings.`;
      const data = await geminiService.generateJSON(prompt);
      res.json({ questions: data });
    } catch (error) {
      console.error("Questions error:", error);
      res.status(500).json({ error: "Failed to generate questions" });
    }
  },

  async analyzeResume(req: Request, res: Response) {
    try {
      const { resumeText } = req.body;
      const prompt = `Analyze the following resume text. Provide a summary of strengths, major weaknesses, and specific tips for improvement. Return as a JSON object with keys: summary, strengths (array), weaknesses (array), suggestedImprovements (array).\n\nResume:\n${resumeText}`;
      const data = await geminiService.generateJSON(prompt);
      res.json(data);
    } catch (error) {
      console.error("Resume analysis error:", error);
      res.status(500).json({ error: "Failed to analyze resume" });
    }
  },

  async getFeedback(req: Request, res: Response) {
    try {
      const { role, transcript } = req.body;
      const transcriptStr = transcript.map((t: any) => `${t.role}: ${t.content}`).join("\n");
      const prompt = `Analyze this interview transcript for a ${role} position and provide feedback. Rate communication, confidence, and preparedness (0-100). Provide detailed improvement tips. Return as JSON with keys: score (overall), communicationScore, confidenceScore, preparednessScore, feedback (string), improvementTips (array of strings).\n\nTranscript:\n${transcriptStr}`;
      const data = await geminiService.generateJSON(prompt);
      res.json(data);
    } catch (error) {
      console.error("Feedback error:", error);
      res.status(500).json({ error: "Failed to generate feedback" });
    }
  },

  async reviewCode(req: Request, res: Response) {
    try {
      const { challenge, code, language } = req.body;
      const prompt = `Act as a senior software engineer conducting a technical interview. Review the following code submission for the challenge: "${challenge.title}". 
        Language: ${language}
        Challenge Description: ${challenge.description}
        Code:
        ${code}
        
        Evaluate the code for correctness, time complexity, space complexity, and code quality. Check for subtle bugs or optimization opportunities.
        Return a JSON object with keys: 
        - score (0-100)
        - summary (string)
        - optimizations (array of strings)
        - timeComplexity (string)
        - spaceComplexity (string)
        - isCorrect (boolean)`;
      const data = await geminiService.generateJSON(prompt);
      res.json(data);
    } catch (error) {
      console.error("Code review error:", error);
      res.status(500).json({ error: "Failed to review code" });
    }
  },

  async generateChallenge(req: Request, res: Response) {
    try {
      const { difficulty, topic } = req.body;
      const prompt = `Generate a coding challenge with difficulty "${difficulty}" on the topic of "${topic}". 
        Return a JSON object with:
        - title (string)
        - description (string, markdown supported)
        - difficulty (string: easy, medium, hard)
        - starterCode (object where keys are languages like 'javascript', 'python' and values are strings)
        - testCases (array of objects with 'input' and 'expectedOutput')
        - constraints (array of strings)`;
      const data = await geminiService.generateJSON(prompt);
      res.json(data);
    } catch (error) {
      console.error("Challenge generation error:", error);
      res.status(500).json({ error: "Failed to generate challenge" });
    }
  }
};
